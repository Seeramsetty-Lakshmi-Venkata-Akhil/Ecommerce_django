class OrderValidationError(Exception):
    """Custom exception for order validation errors"""
    pass