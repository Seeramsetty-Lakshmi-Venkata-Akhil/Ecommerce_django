from django.contrib import admin
from products.models import Products
# Register your models here.
admin.site.register(Products)

